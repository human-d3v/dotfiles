#!/bin/sh
/usr/bin/newm-cmd lock dim
